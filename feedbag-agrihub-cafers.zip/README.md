# Feedbag Agrihub (Cafers)
A decentralized, multilingual, AI-powered agri marketplace leveraging blockchain and escrow to simplify trade, empower farmers, and digitize Africa’s agricultural economy.

## Features
- 🌍 Multilingual accessibility
- 🔒 Escrow automation
- 🔗 Blockchain transparency
- ☁️ AI-driven insights
- 🌱 Sustainable logistics

## Tech Stack
Move • Aptos Build • Node.js • React • Python • IPFS • Algorand

## Quick Start
```bash
git clone https://github.com/FeedbagAgrihub/cafers.git
cd backend && npm install && npm start
```

## Deploy Smart Contracts
```bash
cd contracts
aptos move publish --profile testnet
```
