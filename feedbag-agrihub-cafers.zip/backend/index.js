// Entry point for backend API server
