#!/bin/bash
echo 'Deploying Move contracts to Aptos testnet...'
