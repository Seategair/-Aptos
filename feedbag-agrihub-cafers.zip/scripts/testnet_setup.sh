#!/bin/bash
echo 'Setting up Aptos testnet profile...'
