# Python script for verifying on-chain transactions
